package sistemazoologico;

public class Ave extends Animal implements VACUNABLE {
    private double envergaduraAlas;

    public Ave(String nombre, int edad, double peso, Dieta dieta, double envergaduraAlas) {
        super(nombre, edad, peso, dieta);
        this.envergaduraAlas = envergaduraAlas;
        this.puedeVacunarse = true;
    }

    @Override
    public void vacunar() {
        System.out.println(nombre + " ha sido vacunado.");
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Ave - Envergadura: " + envergaduraAlas + " metros");
    }
}