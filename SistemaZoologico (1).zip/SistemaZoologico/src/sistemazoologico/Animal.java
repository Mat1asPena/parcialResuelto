package sistemazoologico;

public abstract class Animal {
    protected String nombre;
    protected int edad;
    protected double peso;
    protected Dieta dieta;
    protected boolean puedeVacunarse;

    protected Animal(String nombre, int edad, double peso, Dieta dieta) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.dieta = dieta;
    }
    
    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public double getPeso() {
        return peso;
    }

    public boolean isPuedeVacunarse() {
        return puedeVacunarse;
    }
    
    /* @Override
    public String toString() {
        return "Nombre: " + nombre + ", Edad: " + edad + " años, Peso: " + peso + " kg, Dieta: " + dieta;
    }   teniendo en cuenta los datos que se piden no se va a necesitar, pero si se pidiera dar la mostrar toda la informacion de los animales se usaria
    */
    
    public abstract void mostrarInfo();
    
}
    
    

