package sistemazoologico;

import java.util.Scanner;

public class MainConMenu {
    public static void main(String[] args) {
        Zoologico zoologico = new Zoologico();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- Menú del Zoológico ---");
            System.out.println("1. Agregar Mamífero");
            System.out.println("2. Agregar Ave");
            System.out.println("3. Agregar Reptil");
            System.out.println("4. Mostrar Animales");
            System.out.println("5. Vacunar Animales");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    agregarMamifero(zoologico, scanner);
                    break;
                case 2:
                    agregarAve(zoologico, scanner);
                    break;
                case 3:
                    agregarReptil(zoologico, scanner);
                    break;
                case 4:
                    zoologico.mostrarAnimales();
                    break;
                case 5:
                    zoologico.vacunarAnimales();
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida, intente nuevamente.");
                    break;
            }
        } while (opcion != 0);

        scanner.close();
    }

    private static void agregarMamifero(Zoologico zoologico, Scanner scanner) {
        System.out.print("Ingrese nombre del mamífero: ");
        String nombre = scanner.next();
        System.out.print("Ingrese edad del mamífero: ");
        int edad = scanner.nextInt();
        System.out.print("Ingrese peso del mamífero: ");
        double peso = scanner.nextDouble();
        System.out.print("Ingrese dieta (HERVIVORO, CARNIVORO, OMNIVORO): ");
        Dieta dieta = Dieta.valueOf(scanner.next().toUpperCase());

        try {
            Mamifero mamifero = new Mamifero(nombre, edad, peso, dieta);
            zoologico.agregarAnimal(mamifero);
            System.out.println("Mamífero agregado correctamente.");
        } catch (Exception e) {
            System.out.println("Error al agregar mamífero: " + e.getMessage());
        }
    }

    private static void agregarAve(Zoologico zoologico, Scanner scanner) {
        System.out.print("Ingrese nombre del ave: ");
        String nombre = scanner.next();
        System.out.print("Ingrese edad del ave: ");
        int edad = scanner.nextInt();
        System.out.print("Ingrese peso del ave: ");
        double peso = scanner.nextDouble();
        System.out.print("Ingrese dieta (HERVIVORO, CARNIVORO, OMNIVORO): ");
        Dieta dieta = Dieta.valueOf(scanner.next().toUpperCase());
        System.out.print("Ingrese envergadura de las alas: ");
        double envergaduraAlas = scanner.nextDouble();

        try {
            Ave ave = new Ave(nombre, edad, peso, dieta, envergaduraAlas);
            zoologico.agregarAnimal(ave);
            System.out.println("Ave agregada correctamente.");
        } catch (Exception e) {
            System.out.println("Error al agregar ave: " + e.getMessage());
        }
    }

    private static void agregarReptil(Zoologico zoologico, Scanner scanner) {
        System.out.print("Ingrese nombre del reptil: ");
        String nombre = scanner.next();
        System.out.print("Ingrese edad del reptil: ");
        int edad = scanner.nextInt();
        System.out.print("Ingrese peso del reptil: ");
        double peso = scanner.nextDouble();
        System.out.print("Ingrese dieta (HERVIVORO, CARNIVORO, OMNIVORO): ");
        Dieta dieta = Dieta.valueOf(scanner.next().toUpperCase());
        System.out.print("Ingrese tipo de escama: ");
        String tipoEscama = scanner.next();
        System.out.print("Ingrese regulación de temperatura (endotermia, ectotermia): ");
        String regulacionTemperatura = scanner.next();

        try {
            Reptil reptil = new Reptil(nombre, edad, peso, dieta, tipoEscama, regulacionTemperatura);
            zoologico.agregarAnimal(reptil);
            System.out.println("Reptil agregado correctamente.");
        } catch (Exception e) {
            System.out.println("Error al agregar reptil: " + e.getMessage());
        }
    }
}