package sistemazoologico;

public class Mamifero extends Animal implements VACUNABLE {

    public Mamifero(String nombre, int edad, double peso, Dieta dieta) {
        super(nombre, edad, peso, dieta);
        this.puedeVacunarse = true;
    }

    @Override
    public void vacunar() {
        System.out.println(nombre + " ha sido vacunado.");
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Mamifero - Peso: " + peso + " kg, Dieta: " + dieta);
    }
}
