package sistemazoologico;

public enum Dieta {
    HERVIVORO, CARNIVORO, OMNIVORO;
}
