package sistemazoologico;

public class SistemaZoologico {
    public static void main(String[] args) {
        Zoologico zoologico = new Zoologico();

        try {
            Animal leon = new Mamifero("Leon", 5, 190.0, Dieta.CARNIVORO);
            Animal loro = new Ave("Loro", 2, 1.5, Dieta.HERVIVORO, 0.5);
            Animal cocodrilo = new Reptil("Cocodrilo", 10, 300.0, Dieta.CARNIVORO, "Queratinosa", "Ectotermia");

            zoologico.agregarAnimal(leon);
            zoologico.agregarAnimal(loro);
            zoologico.agregarAnimal(cocodrilo);

            System.out.println("Animales en el zoológico:");
            zoologico.mostrarAnimales();

            System.out.println("\nVacunando animales:");
            zoologico.vacunarAnimales();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

