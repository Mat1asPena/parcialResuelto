package sistemazoologico;

public interface VACUNABLE {
    public void vacunar();
}
 