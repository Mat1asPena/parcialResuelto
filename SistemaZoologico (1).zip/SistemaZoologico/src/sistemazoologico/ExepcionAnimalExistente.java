package sistemazoologico;

public class ExepcionAnimalExistente extends Exception {
    public ExepcionAnimalExistente(String mensaje) {
        super(mensaje);
    }
}

