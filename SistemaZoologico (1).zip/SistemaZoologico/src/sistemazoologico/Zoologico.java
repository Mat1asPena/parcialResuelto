package sistemazoologico;

import java.util.ArrayList;

public class Zoologico {
    private ArrayList<Animal> animales;

    public Zoologico() {
        this.animales = new ArrayList<>();
    }

    public void agregarAnimal(Animal animal) throws Exception {
        for (Animal a : animales) {
            if (a.getNombre().equals(animal.getNombre()) && a.getEdad() == animal.getEdad()) {
                throw new Exception("El animal ya existe en el zoologico.");
            }
        }
        animales.add(animal);
    }

    public void mostrarAnimales() {
        for (Animal animal : animales) {
            animal.mostrarInfo();
        }
    }

    public void vacunarAnimales() {
        for (Animal animal : animales) {
            if (animal instanceof VACUNABLE vacunable) {
                vacunable.vacunar();
            } else {
                System.out.println(animal.getNombre() + " no puede ser vacunado.");
            }
        }
    }
}

